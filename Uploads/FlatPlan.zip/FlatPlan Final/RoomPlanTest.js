//Creates main state that contains game
var mainState = {

    preload: function () { //Loads Assets
        game.load.image('bird', 'assets/bird.png');
        game.load.image('pipe', 'assets/pipe.png');
        game.load.image('circle', 'assets/circle.png');
        game.load.image('button', 'assets/bird.png');

    },

    //function is executed after preload, sets up game, sprites, etc.
    create: function () {

        game.stage.backgroundColor = '#deebed';
        game.physics.startSystem(Phaser.Physics.ARCADE);

        //Room Group
        this.roomObs = game.add.group();
        game.physics.arcade.enable(this.roomObs);

        this.juggled = [];
        this.furnitures = [];

        //"Layer" Initialization
        this.layer = '';

        this.dragged = '';
        this.widthIn = 2;
        this.heightIn = 2;
        //    this.colorIn = 0x5d5e63;


        //Change Scale Buttons
        var minusX = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
        minusX.onDown.add(this.scaleXDown, this)
        var minusY = game.input.keyboard.addKey(Phaser.Keyboard.UP);
        minusY.onDown.add(this.scaleYDown, this)
        var plusX = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);
        plusX.onDown.add(this.scaleXUp, this)
        var plusY = game.input.keyboard.addKey(Phaser.Keyboard.DOWN);
        plusY.onDown.add(this.scaleYUp, this)

        //Duplicate Button
        var dupe = game.input.keyboard.addKey(Phaser.Keyboard.Z);
        dupe.onDown.add(this.duplication, this);

        //Delete Button
        var deleteTop = game.input.keyboard.addKey(Phaser.Keyboard.X);
        deleteTop.onDown.add(this.deleteLayer, this);

    },

    update: function () {
        game.physics.arcade.overlap(this.dragged, this.juggled, this.overlap, null, this);
    },



    overlap: function (dSprite, oSprite) {
        if (dSprite.id != oSprite.id) {
            //console.log('overlapping ' + dSprite.id + ', ' + oSprite.id);
            dSprite.tint = 0xff0000;
        } else if (dSprite.id == oSprite.id) {
            //console.log('not ' + dSprite.id + ', ' + oSprite.id);
            oSprite.tint = oSprite.staticTint;
        }
    },



    onDragStart: function (sprite) {
        mainState.dragged = sprite;
        console.log(sprite);
        mainState.layer = mainState.dragged;
        mainState.layer.bringToTop();
        mainState.arrayJuggling();
    },



    onDragStop: function () {
        mainState.dragged = '';
    },

    arrayJuggling: function () {
        var i;
        mainState.juggled = [];
        console.log(mainState.juggled);
        mainState.juggled.push(mainState.dragged);
        //console.log(this.dragged.id)

        for (i = 0; i < mainState.furnitures.length; i++) {
            if (mainState.dragged.id != mainState.furnitures[i].id) {
                mainState.juggled.push(mainState.furnitures[i]);
                //console.log(i);
            }
        }
    },


    //Create Object Functions
    createRoom: function () {
        mainState.newRoom = game.add.sprite(game.world.centerX, game.world.centerY, 'bird');

        mainState.newRoom.scale.setTo(this.roomWidthIn, this.roomHeightIn);
        mainState.newRoom.tint = this.roomColorIn;
        game.physics.arcade.enable(mainState.newRoom);
        mainState.newRoom.body.collideWorldBounds = true;
        mainState.newRoom.anchor.set(0.5);
        mainState.layer = mainState.newRoom;
        mainState.newRoom.inputEnabled = true;

    },
    createRect: function () {
        var newRect = game.add.sprite(game.world.centerX, game.world.centerY, 'bird');
        if (mainState.furnitures.length == 0) {
            newRect.id = 0;
        } else {
            newRect.id = mainState.furnitures.length;
        }

        newRect.scale.setTo(this.rectWidthIn, this.rectHeightIn);
        newRect.tint = this.rectColorIn;
        newRect.staticTint = this.rectColorIn;
        game.physics.arcade.enable(newRect);
        newRect.body.collideWorldBounds = true;
        newRect.anchor.set(0.5);
        newRect.shape = 'rect';

        newRect.inputEnabled = true;

        newRect.input.enableDrag();
        newRect.events.onDragStart.add(mainState.onDragStart);
        newRect.events.onDragStop.add(mainState.onDragStop, this);

        newRect.input.boundsSprite = mainState.newRoom;
        mainState.layer = newRect;
        mainState.furnitures.push(newRect);
    },

    createCircle: function () {
        var newCircle = game.add.sprite(game.world.centerX, game.world.centerY, 'circle');
        if (mainState.furnitures.length == 0) {
            newCircle.id = 0;
        } else {
            newCircle.id = mainState.furnitures.length;
        }

        newCircle.scale.setTo(this.circleWidthIn / 4, this.circleHeightIn / 4);
        newCircle.tint = this.circleColorIn;
        newCircle.staticTint = this.circleColorIn;
        game.physics.arcade.enable(newCircle);
        newCircle.body.collideWorldBounds = true;
        newCircle.anchor.set(0.5);
        newCircle.shape = 'circle';

        newCircle.inputEnabled = true;
        newCircle.input.enableDrag();
        newCircle.events.onDragStart.add(mainState.onDragStart);
        newCircle.events.onDragStop.add(mainState.onDragStop, this);

        newCircle.input.boundsSprite = mainState.newRoom;
        mainState.layer = newCircle;
        mainState.furnitures.push(newCircle);

        console.log("circle made");
    },


    duplication: function () {
        console.log(this.layer.scale.x);
        console.log(this.layer.scale.y);
        this.dupeX = this.layer.scale.x;
        this.dupeY = this.layer.scale.y;
        this.dupeColor = this.layer.tint;

        console.log(this.furnitures.length);

        if (this.layer.shape == 'rect') {
            this.rectWidthIn = this.dupeX;
            this.rectHeightIn = this.dupeY;
            this.rectColor = this.dupeColor;

            mainState.createRect();

            console.log(this.furnitures.length);

        } else if (this.layer.shape == 'circle') {
            this.circleWidthIn = 4 * this.dupeX;
            this.circleHeightIn = 4 * this.dupeY;
            this.circleColor = this.dupeColor;

            mainState.createCircle();

            console.log(this.furnitures.length);

        }
    },

    deleteLayer: function () {

        console.log('delete');

        this.layer.destroy();
        this.juggled.shift();
        this.furnitures = this.juggled;
        this.layer = this.juggled[0];


    },



    //Scaling Functions
    scaleXDown: function () {
        this.layer.scale.setTo(this.layer.scale.x -= 0.07, this.layer.scale.y);
        this.layer.anchor.set(0.5);
    },

    scaleYDown: function () {
        this.layer.scale.setTo(this.layer.scale.x, this.layer.scale.y -= 0.07);
        this.layer.anchor.set(0.5);
    },


    scaleXUp: function () {
        this.layer.scale.setTo(this.layer.scale.x += 0.07, this.layer.scale.y);
        this.layer.anchor.set(0.5);
        console.log("x: " + this.layer.scale.x);
    },

    scaleYUp: function () {
        this.layer.scale.setTo(this.layer.scale.x, this.layer.scale.y += 0.07);
        this.layer.anchor.set(0.5);
        console.log("y: " + this.layer.scale.y);
    },

    //this.room1.visible =! this.room1.visible;

}


var game = new Phaser.Game(990, 785, Phaser.AUTO, 'planner');

//Addes mainState and names it 'main'
game.state.add('main', mainState);

//Initializes state to start game
game.state.start('main');

//make doc ready
$(document).ready(function () {
    $("#defaultOpen").addClass("active");

    $(".button").on("click", function () {
        //console.log(this);
        var clickedButton = $(this).attr("id");
        var rectWidth = $("#rectWidth").val();
        var rectHeight = $("#rectHeight").val();
        var rectColor = $("#rectColor").val();
        var circleWidth = $("#circleWidth").val();
        var circleHeight = $("#circleHeight").val();
        var circleColor = $("#circleColor").val();
        var roomWidth = $("#roomWidth").val();
        var roomHeight = $("#roomHeight").val();
        var roomColor = $("#roomColor").val();

        mainState.roomWidthIn = roomWidth * .84;
        mainState.roomHeightIn = roomHeight * .84;
        mainState.roomColorIn = roomColor;

        mainState.rectWidthIn = rectWidth * .84;
        mainState.rectHeightIn = rectHeight * .84;
        mainState.rectColorIn = rectColor;

        mainState.circleWidthIn = circleWidth * .84;
        mainState.circleHeightIn = circleHeight * .84;
        mainState.circleColorIn = circleColor;

        if (clickedButton == "squares") {
            mainState.createRect();
        }

        if (clickedButton == "circles") {
            mainState.createCircle();
        }
        if (clickedButton == "room") {
            mainState.createRoom();
        }

        if (clickedButton == "dup") {
            mainState.duplication();
        }

        if (clickedButton == "del") {
            mainState.deleteLayer();
        }

        if (clickedButton == "decreaseX") {
            mainState.scaleXDown();
        }

        if (clickedButton == "increaseX") {
            mainState.scaleXUp();
        }

        if (clickedButton == "decreaseY") {
            mainState.scaleYDown();
        }

        if (clickedButton == "increaseY") {
            mainState.scaleYUp();
        }




    });

});


// UI functionality
function openTab(evt, customType) {
    console.log("testing");
    var i, tabcontent, tablinks;

    document.getElementById("defaultOpen").click();

    // Get all elements with class="tabcontent" and hide them
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Get all elements with class="tablinks" and remove the class "active"
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Show the current tab, and add an "active" class to the button that opened the tab
    document.getElementById(customType).style.display = "block";
    evt.currentTarget.className += " active";
}


// reload page
function refresh() {
    window.location.reload();
}
