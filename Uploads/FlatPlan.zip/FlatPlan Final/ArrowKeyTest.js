//Creates main state that contains game
var mainState = {

    preload: function () { //Loads Assets
        game.load.image('bird', 'assets/bird.png');
        game.load.image('pipe', 'assets/pipe.png');

    },


    //function is executed after preload, sets up game, sprites, etc.
    create: function () {

        game.stage.backgroundColor = '#71c5cf';
        game.physics.startSystem(Phaser.Physics.ARCADE);

        //this.bird.body.gravity.y = 1000;

        //this.timer = game.time.events.loop(1500, this.addRowOfPipes, this);

        //Room Group
        this.roomObs = game.add.group();
        game.physics.arcade.enable(this.roomObs);


        //Furniture Group
        this.furnitureGroup = game.add.group();
        game.physics.arcade.enable(this.furnitureGroup);


        //Room/White
        this.room1 = game.add.sprite(100, 100, 'bird');
        game.physics.arcade.enable(this.room1);
        this.room1.body.collideWorldBounds = true;
        this.room1.scale.setTo(5, 5);
        this.roomObs.add(this.room1);


        //Bird/Blue
        this.bird1 = game.add.sprite(200, 200, 'bird');
        game.physics.arcade.enable(this.bird1);
        this.bird1.body.collideWorldBounds = true;
        this.bird1.body.immovable = true;

        this.bird1.anchor.set(0.5);
        this.birdXScale = 1;
        this.birdYScale = 1;
        this.furnitureGroup.add(this.bird1);

        //this.bird1.inputEnabled = true;
        //this.bird1.input.enableDrag(true);

        this.bird1.tint = 0x0000ff;

        //this.bird1.inputEnabled = true;
        // this.bird1.input.boundsSprite = this.room1;



        //Pipe/Red
        this.pipe1 = game.add.sprite(275, 275, 'pipe');
        game.physics.arcade.enable(this.pipe1);
        this.pipe1.body.collideWorldBounds = true;
        this.pipe1.body.immovable = true;

        this.pipeXScale = 1;
        this.pipeYScale = 1;
        this.furnitureGroup.add(this.pipe1);

        //this.pipe1.inputEnabled = true;
        //this.pipe1.input.enableDrag(true);

        this.pipe1.tint = 0xff0000;

        // this.pipe1.inputEnabled = true;
        //this.pipe1.input.boundsSprite = this.room1;

        //Variables
        var mouseX = game.input.x;
        var mouseY = game.input.y;
        this.list = 0;


        //Furniture Array
        this.furnitureList = [this.bird1, this.pipe1];






        //"Layer" Initialization
        this.layer = this.bird1;
        var toggleLayer = game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
        toggleLayer.onDown.add(this.layerToggle, this);


        //Movement
        var moveUp = game.input.keyboard.addKey(Phaser.Keyboard.W);
        moveUp.onDown.add(this.move1, this);
        var moveDown = game.input.keyboard.addKey(Phaser.Keyboard.S);
        moveDown.onDown.add(this.move2, this);
        var moveLeft = game.input.keyboard.addKey(Phaser.Keyboard.A);
        moveLeft.onDown.add(this.move3, this);
        var moveRight = game.input.keyboard.addKey(Phaser.Keyboard.D);
        moveRight.onDown.add(this.move4, this);


        //Change Scale
        var minusX = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
        minusX.onDown.a
        dd(this.scaleXDown, this)
        var minusY = game.input.keyboard.addKey(Phaser.Keyboard.UP);
        minusY.onDown.add(this.scaleYDown, this)

        var plusX = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);
        plusX.onDown.add(this.scaleXUp, this)
        var plusY = game.input.keyboard.addKey(Phaser.Keyboard.DOWN);
        plusY.onDown.add(this.scaleYUp, this)


        //Toggle Layer
        var toggleLayer = game.input.keyboard.addKey(Phaser.Keyboard.ONE);
        toggleLayer.onDown.add(this.layerToggle, this);



    },

    //Function is called at 60 fps, contains game's logic
    update: function () {
        var overlap = false;
        this.focused = this.furnitureList[this.list];

        game.physics.arcade.collide(this.bird1, this.pipe1);








        this.bird1.scale.setTo(this.birdXScale, this.birdYScale);
        this.pipe1.scale.setTo(this.pipeXScale, this.pipeYScale);


    },






    //Restarts the game
    layerToggle: function () {
        if (this.list < this.furnitureList.length) {
            this.list += 1;
            console.log('next');
        } else {
            this.list = 0;
            console.log('restart');
        }
        console.log(this.furnitureList[this.list]);


    },


    //Scaling
    scaleXDown: function () {
        if (this.layer == this.bird1) {
            this.birdXScale -= 0.1;
        } else if (this.layer == this.pipe1) {
            this.pipeXScale -= 0.1;
        }
    },

    scaleYDown: function () {
        if (this.layer == this.bird1) {
            this.birdYScale -= 0.1;
        } else if (this.layer == this.pipe1) {
            this.pipeYScale -= 0.1;
        }
    },


    scaleXUp: function () {
        if (this.layer == this.bird1) {
            this.birdXScale += 0.1;
        } else if (this.layer == this.pipe1) {
            this.pipeXScale += 0.1;
        }
    },

    scaleYUp: function () {
        if (this.layer == this.bird1) {
            this.birdYScale += 0.1;
        } else if (this.layer == this.pipe1) {
            this.pipeYScale += 0.1;
        }
    },


    //Movement
    move1: function () {
        this.focused.y -= 10;
    },

    move2: function () {
        this.focused.y += 10;
    },

    move3: function () {
        this.focused.x -= 10;
    },

    move4: function () {
        this.focused.x += 10;
    },




};

var game = new Phaser.Game(500, 500);

//Addes mainState and names it 'main'
game.state.add('main', mainState);

//Initializes state to start game
game.state.start('main');

/*

Un-used but maybe useful code:
if (this.bird1.overlap(this.pipe1)) {
            if (this.bird1.x < this.pipe1.x) {
                if (this.bird1.x - this.bird1.width / 2 == this.room1.x) {
                    this.bird1.x += 3;
                } else {
                    this.bird1.x -= 3;
                }

            } else if (this.bird1.x > this.pipe1.x) {
                if (this.bird1.x + this.bird1.width / 2 == this.room1.width) {
                    this.bird1.x -= 3;
                } else {
                    this.bird1.x += 3;
                }

            }
            if (this.bird1.y < this.pipe1.y) {
                if (this.bird1.y - this.bird1.height / 2 == this.room1.y) {
                    this.bird1.y += 3;
                } else {
                    this.bird1.y -= 3;
                }
            } else if (this.bird1.y > this.pipe1.y) {
                if (this.bird1.y + this.bird1.height / 2 == this.room1.height) {
                    this.bird1.x -= 3;
                } else {
                    this.bird1.y += 3;
                }
            }

        }
        */

